package com.test.app;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.TimeZone;

import org.eclipse.jetty.server.Server;
import org.glassfish.jersey.jetty.JettyHttpContainerFactory;
import org.glassfish.jersey.server.ResourceConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Main {
	private static Logger LOGGER = LoggerFactory.getLogger(Main.class);

	public static final String BASE_URI = "http://localhost:8080/";

	public static Server startServer() {

		// scan packages
		final ResourceConfig config = new ResourceConfig().packages("com.test.app");

		// final ResourceConfig config = new ResourceConfig(Resource.class);
		final Server server = JettyHttpContainerFactory.createServer(URI.create(BASE_URI), config);

		return server;

	}

	public static void main(String[] args) {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

		LOGGER.debug("debug message");
		LOGGER.info("info message");
		LOGGER.warn("warn message");
		LOGGER.error("error message");

		// rest client
		OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
		Retrofit retrofit = new Retrofit.Builder().baseUrl("http://localhost/ping/")
				.addConverterFactory(GsonConverterFactory.create()).client(httpClient.build()).build();
		UserService service = retrofit.create(UserService.class);
		Call<String> callAsync = service.getUser("eugenp");

		callAsync.enqueue(new Callback<String>() {
			@Override
			public void onResponse(Call<String> call, Response<String> response) {
				String user = response.body();
			}

			@Override
			public void onFailure(Call<String> call, Throwable throwable) {
				LOGGER.error(throwable.getMessage(), throwable);
			}
		});

		// entity
		Entity entity = new Entity(12345, "Teste");
		System.out.println(entity.toString());

		// database
		try (Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/chatty", "markvanbeek",
				"")) {

			if (conn != null) {
				System.out.println("Connected to the database!");
				String query = "select * from users";
				try (Statement stmt = conn.createStatement()) {
					ResultSet rs = stmt.executeQuery(query);
					while (rs.next()) {
						String name = rs.getString("name");
						System.out.println(name);
					}
				} catch (SQLException e) {
					LOGGER.error(e.getMessage(), e);
				}
			} else {
				System.out.println("Failed to make connection!");
			}

		} catch (SQLException e) {
			System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			final Server server = startServer();

			Runtime.getRuntime().addShutdownHook(new Thread(() -> {
				try {
					System.out.println("Shutting down the application...");
					server.stop();
					System.out.println("Done, exit.");
				} catch (Exception e) {
					LOGGER.error(e.getMessage(), e);
				}
			}));

			System.out.println(String.format("Application started.%nStop the application using CTRL+C"));

			// block and wait shut down signal, like CTRL+C
			Thread.currentThread().join();

			// alternative
			// Thread.sleep(Long.MAX_VALUE); // sleep forever...
			// Thread.sleep(Integer.MAX_VALUE); // sleep around 60+ years

		} catch (InterruptedException ex) {
			LOGGER.error(ex.getMessage(), ex);
		}

	}

}